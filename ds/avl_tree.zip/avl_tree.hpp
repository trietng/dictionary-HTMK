#pragma once

unsigned int max(const unsigned int& x, const unsigned int& y);

class avl_node {
public:
	int data;
	unsigned int height;
	avl_node* left;
	avl_node* right;
	avl_node(const int& data);
	~avl_node();
};

class avl_tree {
private:
	avl_node* root;
	//Return the height of the node
	unsigned int height(avl_node* node);
	//Right rotation
	avl_node* right_rotate(avl_node* node);
	//Left rotation
	avl_node* left_rotate(avl_node* node);
	//Return the difference between the heights of the two children
	int difference(avl_node* node);
	//Return the leftmost child
	avl_node* leftmost(avl_node* node);
	//Private recursive insertion operation
	avl_node* insert(avl_node* root, const int& data);
	//Private recursive removal operation
	avl_node* remove(avl_node* root, const int& data);
public:
	avl_tree();
	~avl_tree();
	//Insert data into the AVL tree
	void insert(const int& data);
	void remove(const int& data);
	avl_node* find(const int& data);
};