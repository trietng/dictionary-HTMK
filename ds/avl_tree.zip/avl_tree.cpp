#include "avl_tree.hpp"

unsigned int max(const unsigned int& x, const unsigned int& y) {
	return (x > y) ? x : y;
}

avl_node::avl_node(const int& data) {
	this->data = data;
	height = 1;
	left = right = nullptr;
}

avl_node::~avl_node() {
	delete left;
	delete right;
}

unsigned int avl_tree::height(avl_node* node) {
	return (node) ? node->height : 0;
}

avl_node* avl_tree::right_rotate(avl_node* node) {
	/*
	Right rotation illustration
			3 {node}        2
		   / \             / \
		  2 {top}      ->     3
		 / \                 / \
			1 {bottom}      1
	*/
	avl_node* top = node->left;
	avl_node* bottom = top->right;
	top->right = node;
	node->left = bottom;
	node->height = max(height(node->left), height(node->right)) + 1;
	top->height = max(height(top->left), height(top->right)) + 1;
	return top;
}

avl_node* avl_tree::left_rotate(avl_node* node) {
	avl_node* top = node->right;
	avl_node* bottom = top->left;
	top->left = node;
	node->right = bottom;
	node->height = max(height(node->left), height(node->right)) + 1;
	top->height = max(height(top->left), height(top->right)) + 1;
	return top;
}

int avl_tree::difference(avl_node* node) {
	return (node) ? (height(node->left) - height(node->right)) : 0;
}

avl_node* avl_tree::leftmost(avl_node* node) {
	if (!node) return nullptr;
	avl_node* cur = node;
	while (cur->left) {
		cur = cur->left;
	}
	return cur;
}

avl_node* avl_tree::insert(avl_node* root, const int& data) {
	if (!root) return new avl_node(data);
	else if (data < root->data) root->left = insert(root->left, data);
	else if (data > root->data) root->right = insert(root->right, data);
	else return root;
	root->height = max(height(root->left), height(root->right)) + 1;
	int d = difference(root);
	if (d > 1) {
		//TRUE: LEFT RIGHT, FALSE: LEFT LEFT
		if (data > root->left->data) root->left = left_rotate(root->left);
		return right_rotate(root);
	}
	if (d < -1) {
		//TRUE: RIGHT LEFT, FALSE: RIGHT RIGHT
		if (data < root->right->data) root->right = right_rotate(root->right);
		return left_rotate(root);
	}
	return root;
}

avl_node* avl_tree::remove(avl_node* root, const int& data) {
	if (!root) return root;
	else if (data < root->data) root->left = remove(root->left, data);
	else if (data > root->data) root->right = remove(root->right, data);
	else {
		if ((!root->left) || (!root->right)) {
			avl_node* child = (root->left) ? (root->left) : (root->right);
			if (child) {
				*root = *child;
			}
			else {
				child = root;
				root = nullptr;
			}
			delete child;
		}
		else {
			avl_node* tmp = leftmost(root->right);
			root->data = tmp->data;
			root->right = remove(root->right, tmp->data);
		}
	}
	if (!root) return root;
	root->height = max(height(root->left), height(root->right)) + 1;
	int d = difference(root);
	if (d > 1) {
		//TRUE: LEFT RIGHT, FALSE: LEFT LEFT
		if (difference(root->left) < 0) root->left = left_rotate(root->left);
		return right_rotate(root);
	}
	if (d < -1) {
		//TRUE: RIGHT LEFT, FALSE: RIGHT RIGHT
		if (difference(root->right) > 0) root->right = right_rotate(root->right);
		return left_rotate(root);
	}
	return root;
}

avl_tree::avl_tree() {
	root = nullptr;
}

avl_tree::~avl_tree() {
	delete root;
}

void avl_tree::insert(const int& data) {
	root = insert(root, data);
}