#pragma once
#include <iostream>
#include <fstream>
#include "ds\trie.hpp"

template <unsigned int N_WORD, unsigned int N_DEF>
class dictionary {
private:
	trie<N_WORD> word;
	trie<N_DEF> definition;
	std::string filename;
	void write(tnode<N_WORD>* root, std::ofstream& fout) {
		if (!root) return;
		if (!root->value.empty()) {
			auto ent = root->value.front().get();
			fout << ent->key << "`" << ent->value << "\n";
		}
		for (unsigned int i = 0; i < N_WORD; ++i) {
			write(root->next[i], fout);
		}
	}
public:
	dictionary(const std::string& filename) {
		std::ifstream fin(filename);
		this->filename = filename;
		if (fin) {
			std::string line, word, def;
			while (getline(fin, line)) {
				std::stringstream ss(line);
				std::getline(ss, word, '`');
				std::getline(ss, def);
				insert(word, def);
			}
		}
	}
	//Insert new entry into the dictionary
	void insert(const std::string& word, const std::string& definition) {
		shptr<entry> ent(new entry(word, definition));
		this->word.insert(ent);
		this->definition.insert_d(ent);
	}
	//Remove word from dictionary
	void remove(const std::string& word) {
		this->word.remove(word);
	}
	//Find word
	entry* find_word(const std::string& word) {
		return this->word.find(word);
	}
	//Find definition
	std::vector<entry*> find_definition(const std::string& keyword) {
		return this->definition.find_d(keyword);
	}
	//Write data to file
	void write() {
		std :: ofstream fout(filename);
		fout.close();
		fout.open(filename, std::ios::app);
		if (fout) write(word.top(), fout);
	}
	void clear() {
		word.clear();
		definition.clear();
	}
	//Find random word
	entry* find_rand_word() {

	}
};